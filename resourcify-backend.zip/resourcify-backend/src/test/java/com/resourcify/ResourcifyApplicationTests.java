package com.resourcify;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResourcifyApplicationTests {

	@Test
	void contextLoads() {
	}

}
