package com.resourcify;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResourcifyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResourcifyApplication.class, args);
	}

}
